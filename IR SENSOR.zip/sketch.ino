#define TRIG 9
#define ECHO 8
#define LED 10
#define BUZZER 11

void setup() {
    pinMode(TRIG, OUTPUT);
    pinMode(ECHO, INPUT);
    pinMode(LED, OUTPUT);
    pinMode(BUZZER, OUTPUT);
    Serial.begin(9600);
}

void loop() {
    digitalWrite(TRIG, LOW);
    delayMicroseconds(2);
    digitalWrite(TRIG, HIGH);
    delayMicroseconds(10);
    digitalWrite(TRIG, LOW);

    long duration = pulseIn(ECHO, HIGH);
    int distance = duration * 0.034 / 2;

    Serial.print("Distance: ");
    Serial.print(distance);
    Serial.println(" cm");

    if (distance < 15) {
        digitalWrite(LED, HIGH);
        tone(BUZZER, 500);
        delay(200);
        digitalWrite(LED, LOW);
        noTone(BUZZER);
        delay(200);
    } else {
        digitalWrite(LED, LOW);
        noTone(BUZZER);
    }
    delay(500);
}