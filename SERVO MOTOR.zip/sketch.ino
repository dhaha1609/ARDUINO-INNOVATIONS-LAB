#include "Servo.h"
const int servoPin = 5;
Servo Servo1;
void setup() 
{  
   Servo1.attach(servoPin);
}

void loop()
{ 
   Servo1.write(0);
   delay(200); 
   Servo1.write(90);
   delay(50);
   Servo1.write(180);
   delay(200); 
}