const int LED_pin=13, switch_pin=3;
void setup() {
  pinMode(LED_pin, OUTPUT);
  pinMode(switch_pin, INPUT_PULLUP);
}

void loop() {
  int switch_state=digitalRead(switch_pin);
  digitalWrite(LED_pin, switch_state);  
}
