#include <Wire.h>
#include <LiquidCrystal_I2C.h>
#include <DHT.h>
#include <Servo.h>

const int trigPin = 9;       
const int echoPin = 10;      
const int ledPin = 13;       
const int buzzerPin = 8;     
const int dhtPin = 7;     
const int dhtType = DHT11;
const int servoPin = 6;   
LiquidCrystal_I2C lcd(0x27, 16, 2);

DHT dht(dhtPin, dhtType);
Servo servoMotor;  

long duration;
int distance;
int thresholdDistance = 30;  
float temperature;
float humidity;
int thresholdTemperature = 30;
bool showDHT = true; 
void setup() {
  pinMode(trigPin, OUTPUT);
  pinMode(echoPin, INPUT);
  pinMode(ledPin, OUTPUT);
  pinMode(buzzerPin, OUTPUT);
  Serial.begin(9600);
  dht.begin();
  lcd.init();
  lcd.backlight();
  servoMotor.attach(servoPin);
}

void loop() {
  digitalWrite(trigPin, LOW);
  delayMicroseconds(2);
  digitalWrite(trigPin, HIGH);
  delayMicroseconds(10);
  digitalWrite(trigPin, LOW);
  duration = pulseIn(echoPin, HIGH);
  distance = duration * 0.034 / 2;
  lcd.setCursor(0, 0);
  lcd.print("Distance :");
  lcd.print(distance);
  lcd.print("cm ");
  temperature = dht.readTemperature();
  humidity = dht.readHumidity();
  if (distance < thresholdDistance || temperature > thresholdTemperature) {
    digitalWrite(ledPin, HIGH);
    digitalWrite(buzzerPin, HIGH);
    Serial.println("Warning!");
    servoMotor.write(120); 
  } else {
    digitalWrite(ledPin, LOW);
    digitalWrite(buzzerPin, LOW);
    Serial.println("No warning.");
    servoMotor.write(0); 
  }
  if (showDHT) {
    lcd.setCursor(0, 1);
    lcd.print("Temp : ");
    lcd.print(temperature);
    lcd.print(" C ");
    showDHT = false;
  } else {
    lcd.setCursor(0, 1);
    lcd.print("Humidity: ");
    lcd.print(humidity);
    lcd.print("%");
    showDHT = true;
  }

  delay(2000); 
}
