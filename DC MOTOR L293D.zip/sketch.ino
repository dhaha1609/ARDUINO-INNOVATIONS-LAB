int EN = 10;
int IN1 = 11;
int IN2 = 9;

void setup() {
  pinMode(EN, OUTPUT);
  pinMode(IN1, OUTPUT);
  pinMode(IN2, OUTPUT);
}

void loop() {
  // Forward
  digitalWrite(IN1, HIGH);
  digitalWrite(IN2, LOW);
  analogWrite(EN, 200);
  delay(3000);

  // Stop
  analogWrite(EN, 0);
  delay(1000);

  // Reverse
  digitalWrite(IN1, LOW);
  digitalWrite(IN2, HIGH);
  analogWrite(EN, 200);
  delay(3000);

  // Stop
  analogWrite(EN, 0);
  delay(1000);
}
